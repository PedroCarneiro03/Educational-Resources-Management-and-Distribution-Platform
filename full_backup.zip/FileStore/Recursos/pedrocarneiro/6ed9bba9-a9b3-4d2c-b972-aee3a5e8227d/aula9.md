# Aula sobre docker

Objetivo é pegar em websites estaticos e fazer com que eles sejam hospedados. Para isso criamos um docker com uma imagem em um dockerfile,
pode ser usaado apache, python ou nginx

# DOCKER FILE COMANDOS
## Indicamos a imageem de base
FROM node:15
## Criamos a pasta de trabalho dentro da imagem
WORKDIR / app
## Corre comandos durante o processo de instalação
RUN npm install
## Copiar conteudo para dentro
COPY package.json /app


O QUE NOS QUEREMOS É CRIAR IMAGENS QUE PODEM SER EXECUTADAS EM CONTAINERS APARTIR DE DOCKER FILES


```
docker build -t jcr/<NOME-CONTAINER> .       -- Constuir imagem docker apartir de docker file
docker images
docker run -d -p 3000:7777 --name <NOME_CONTAINTER> <ID_imagem>
docker logs <NOME_CONTAINER>
```

flags: -d é detach significa que a consola fica a correr em background
portas: porta_ext:porta_int
--name: permite dar nome ao container



# GESTAO DE CONTAINERS
```
docker ps                        - lista containers em execução (Process status)
docker stop <NOME_CONTAINER>     - Parar o container
docker rm <NOME_CONTAINER>       - Remover container
docker logs <NOME_CONTAINER> -f  - Nao me lembro o que este faz
```

# Colocar mongo a dar num container
obter imagem: ``` docker pull mongo```

